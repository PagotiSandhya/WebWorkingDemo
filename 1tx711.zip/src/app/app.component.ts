import { Component } from "@angular/core";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  title = "App";
  rows = 8; // add no of  rows
  cols = 5; // add no of cols
  res = [];
  ngOnInit() {
    this.getArrayofNum(this.rows).forEach((elem) => {
      const s = [];
      this.getArrayofNum(this.cols).forEach((ele) => {
        s.push("");
      });
      this.res.push(s);
    });
    console.log(this.res);
  }

  arrayToCsv(data) {
    return data
      .map(
        (row) =>
          row
            .map(String) // convert every value to String
            .map((v) => v.replaceAll('"', '""')) // escape double colons
            .map((v) => `"${v}"`) // quote it
            .join(",") // comma-separated
      )
      .join("\r\n"); // rows starting on new lines
  }

  downloadBlob(content, filename, contentType) {
    // Create a blob
    var blob = new Blob([content], { type: contentType });
    var url = URL.createObjectURL(blob);

    // Create a link to download it
    var pom = document.createElement("a");
    pom.href = url;
    pom.setAttribute("download", filename);
    pom.click();
  }

  exportCsv() {
    this.downloadBlob(
      this.arrayToCsv(this.res),
      "export.csv",
      "text/csv;charset=utf-8;"
    );
  }

  getArrayofNum(data) {
    let i = [];
    for (let j = 1; j <= data; j++) i.push(j);
    return i;
  }
}
